local cfg = {
    enable_adminapi = 1
}

return cfg