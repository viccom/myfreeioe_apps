local model_table = {
	["2-30002"] = {['com1'] = {['name']='ttymxc0', ['port']='4801'},['com2'] = {['name']='ttymxc1', ['port']='4802'}},
	["T70LRUL"] = {['com1'] = {['name']='ttyS1', ['port']='4801'},['com2'] = {['name']='ttyS2', ['port']='4802'}},
}
return model_table